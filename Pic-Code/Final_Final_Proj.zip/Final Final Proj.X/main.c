/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC18F16Q41
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/
  
#include "mcc_generated_files/mcc.h"
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "mcc_generated_files/i2c1_master.h"
#include <string.h>
#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/uart1.h"
#include "mcc_generated_files/examples/i2c1_master_example.h"

/*
                         Main application
 */
char receive[100];
char dir1[100];
char dir2[100];
volatile uint8_t words; 
float values;
int ii;
volatile uart1_status_t rxStatus;
double Temp = 0;
double Hum = 0;
uint8_t dbuff[8];
uint8_t sbuff[8];
uint16_t tconv = 0;
uint16_t hconv = 0;

void UART1_Recieve_ISR(void) {
    UART1_Receive_ISR();
    if (UART1_is_rx_ready()) {
        words = UART1_Read();
    }
    if (UART1_is_tx_ready()) {
        LED_Toggle();
        UART1_Write(words);
    }
}



void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();
    UART1_Initialize();
    SPI1_Initialize();
    

    INTERRUPT_GlobalInterruptEnable();

    UART1_SetRxInterruptHandler(UART1_Recieve_ISR);

    while (1)
    {
            dir1[0] = 0b11001111;
            dir2[0] = 0b11001101;
            
    
        //we want to trigger the chip to take a 'measurement' and wait for that to happen;
        I2C1_ReadNBytes(0x37, dbuff, 1);
        __delay_ms(100);
        I2C1_ReadNBytes(0x70, sbuff, 1);
        __delay_ms(100); 
        I2C1_ReadNBytes(0x37, dbuff, 8);
        __delay_ms(100);
        I2C1_ReadNBytes(0x70, sbuff, 8);
        tconv = (dbuff[0] << 8 | dbuff[1]) & 0x7F;
        hconv = (sbuff[0] << 8 | sbuff[1]) & 0x70;
        Hum = (hconv/65536.0);
        Temp = (tconv * 0.625);
        printf("The Temperature is %f %% \r\n", Temp);
        printf("The Humidity is %f %% \r\n", Hum);
            
      if(Temp<=80) { 
        SPI1_Open(SPI1_DEFAULT);
        ss_pin_SetLow();
        printf("Send: %s\r\n",dir1);

         SPI1_ExchangeBlock(dir1,1);
         receive[0]= dir1[0];
        printf("Receive: %c\r\n",receive[0]);
        ss_pin_SetHigh();
        SPI1_Close();

        __delay_ms(50);
      }
      
      if(Temp>=80){
        SPI1_Open(SPI1_DEFAULT);
        ss_pin_SetLow();
        printf("Send: %s\r\n",dir2);

        SPI1_ExchangeBlock(dir2,1);
        receive[0]= dir2[0];
        printf("Receive: %s\r\n",receive);
        
        ss_pin_SetHigh();
        SPI1_Close();
        __delay_ms(50);
         
    }

        
        


       
    }
}

